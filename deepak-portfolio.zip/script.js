// Add animations or interactive elements here in future
console.log("Welcome to Deepak's portfolio!");
